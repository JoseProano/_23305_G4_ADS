import ui.InterfazUsuario;

/**
 * Clase principal del Sistema de Gestión de Estudiantes
 * Implementa arquitectura de 3 capas con patrón MVC
 * 
 * Capas:
 * - Presentación (UI): InterfazUsuario
 * - Lógica de Negocio (Controller): EstudianteController  
 * - Acceso a Datos (DAO): EstudianteDAO
 */
public class Main {
    public static void main(String[] args) {
        InterfazUsuario interfaz = new InterfazUsuario();
        interfaz.iniciar();
    }
}

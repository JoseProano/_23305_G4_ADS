package ui;

import controller.EstudianteController;
import model.Estudiante;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Clase que maneja toda la interfaz gráfica del sistema
 * Proporciona una ventana con botones y formularios para gestionar estudiantes
 * Implementa la capa de presentación en la arquitectura MVC usando Swing
 */
public class InterfazUsuario extends JFrame {
    private EstudianteController controller;
    private JTable tablaEstudiantes;
    private DefaultTableModel modeloTabla;
    private JTextField txtId, txtApellidos, txtNombres, txtEdad, txtBuscar;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnBuscar, btnLimpiar, btnEstadisticas;

    public InterfazUsuario() {
        this.controller = new EstudianteController();
        inicializarComponentes();
        cargarDatosEjemplo();
        actualizarTabla();
    }

    public void iniciar() {
        setVisible(true);
    }

    private void inicializarComponentes() {
        setTitle("Sistema de Gestión de Estudiantes - Arquitectura 3 Capas + MVC");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setSize(900, 600);
        setLocationRelativeTo(null);

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de formulario
        JPanel panelFormulario = crearPanelFormulario();
        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);

        // Panel de tabla
        JPanel panelTabla = crearPanelTabla();
        panelPrincipal.add(panelTabla, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = crearPanelBotones();
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        add(panelPrincipal);
    }

    private JPanel crearPanelFormulario() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Datos del Estudiante"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // ID
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        txtId = new JTextField(10);
        panel.add(txtId, gbc);

        // Apellidos
        gbc.gridx = 2; gbc.gridy = 0;
        panel.add(new JLabel("Apellidos:"), gbc);
        gbc.gridx = 3;
        txtApellidos = new JTextField(15);
        panel.add(txtApellidos, gbc);

        // Nombres
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Nombres:"), gbc);
        gbc.gridx = 1;
        txtNombres = new JTextField(15);
        panel.add(txtNombres, gbc);

        // Edad
        gbc.gridx = 2; gbc.gridy = 1;
        panel.add(new JLabel("Edad:"), gbc);
        gbc.gridx = 3;
        txtEdad = new JTextField(10);
        panel.add(txtEdad, gbc);

        return panel;
    }

    private JPanel crearPanelTabla() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Lista de Estudiantes"));

        // Crear modelo de tabla
        String[] columnas = {"ID", "Apellidos", "Nombres", "Edad"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablaEstudiantes = new JTable(modeloTabla);
        tablaEstudiantes.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaEstudiantes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarEstudiante();
            }
        });

        JScrollPane scrollPane = new JScrollPane(tablaEstudiantes);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Panel de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.add(new JLabel("Buscar por ID:"));
        txtBuscar = new JTextField(15);
        panelBusqueda.add(txtBuscar);
        btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(_ -> buscarPorId());
        panelBusqueda.add(btnBuscar);

        JButton btnMostrarTodos = new JButton("Mostrar Todos");
        btnMostrarTodos.addActionListener(_ -> actualizarTabla());
        panelBusqueda.add(btnMostrarTodos);

        panel.add(panelBusqueda, BorderLayout.NORTH);

        return panel;
    }

    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel(new FlowLayout());

        btnAgregar = new JButton("Agregar");
        btnAgregar.addActionListener(_ -> agregarEstudiante());
        panel.add(btnAgregar);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(_ -> actualizarEstudiante());
        panel.add(btnActualizar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(_ -> eliminarEstudiante());
        panel.add(btnEliminar);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.addActionListener(_ -> limpiarFormulario());
        panel.add(btnLimpiar);

        btnEstadisticas = new JButton("Estadísticas");
        btnEstadisticas.addActionListener(_ -> mostrarEstadisticas());
        panel.add(btnEstadisticas);

        return panel;
    }

    private void cargarDatosEjemplo() {
        controller.crearEstudiante(1, "Pérez", "Ana", 20);
        controller.crearEstudiante(2, "García", "Luis", 22);
        controller.crearEstudiante(3, "Rodríguez", "María", 19);
        controller.crearEstudiante(4, "López", "Carlos", 21);
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);
        List<Estudiante> estudiantes = controller.obtenerTodos();
        
        for (Estudiante estudiante : estudiantes) {
            Object[] fila = {
                estudiante.getId(),
                estudiante.getApellidos(),
                estudiante.getNombres(),
                estudiante.getEdad()
            };
            modeloTabla.addRow(fila);
        }
    }

    private void seleccionarEstudiante() {
        int filaSeleccionada = tablaEstudiantes.getSelectedRow();
        if (filaSeleccionada >= 0) {
            txtId.setText(modeloTabla.getValueAt(filaSeleccionada, 0).toString());
            txtApellidos.setText(modeloTabla.getValueAt(filaSeleccionada, 1).toString());
            txtNombres.setText(modeloTabla.getValueAt(filaSeleccionada, 2).toString());
            txtEdad.setText(modeloTabla.getValueAt(filaSeleccionada, 3).toString());
        }
    }

    private void agregarEstudiante() {
        try {
            int id = Integer.parseInt(txtId.getText().trim());
            String apellidos = txtApellidos.getText().trim();
            String nombres = txtNombres.getText().trim();
            int edad = Integer.parseInt(txtEdad.getText().trim());

            if (apellidos.isEmpty() || nombres.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Los campos Apellidos y Nombres son obligatorios.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.crearEstudiante(id, apellidos, nombres, edad)) {
                JOptionPane.showMessageDialog(this, "Estudiante agregado correctamente.", 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Error al agregar estudiante. El ID ya existe o los datos son inválidos.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID y Edad deben ser números válidos.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarEstudiante() {
        try {
            int id = Integer.parseInt(txtId.getText().trim());
            String apellidos = txtApellidos.getText().trim();
            String nombres = txtNombres.getText().trim();
            int edad = Integer.parseInt(txtEdad.getText().trim());

            if (apellidos.isEmpty() || nombres.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Los campos Apellidos y Nombres son obligatorios.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.buscarEstudiante(id) == null) {
                JOptionPane.showMessageDialog(this, "No existe un estudiante con ese ID.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.actualizarEstudiante(id, apellidos, nombres, edad)) {
                JOptionPane.showMessageDialog(this, "Estudiante actualizado correctamente.", 
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
                limpiarFormulario();
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar estudiante.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID y Edad deben ser números válidos.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarEstudiante() {
        try {
            int id = Integer.parseInt(txtId.getText().trim());
            
            Estudiante estudiante = controller.buscarEstudiante(id);
            if (estudiante == null) {
                JOptionPane.showMessageDialog(this, "No existe un estudiante con ese ID.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirmacion = JOptionPane.showConfirmDialog(this, 
                "¿Está seguro de eliminar al estudiante " + estudiante.getNombres() + " " + estudiante.getApellidos() + "?", 
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                if (controller.eliminarEstudiante(id)) {
                    JOptionPane.showMessageDialog(this, "Estudiante eliminado correctamente.", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    limpiarFormulario();
                    actualizarTabla();
                } else {
                    JOptionPane.showMessageDialog(this, "Error al eliminar estudiante.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un ID válido.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarPorId() {
        String idTexto = txtBuscar.getText().trim();
        if (idTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID para buscar.", 
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int id = Integer.parseInt(idTexto);
            Estudiante estudiante = controller.buscarEstudiante(id);
            
            modeloTabla.setRowCount(0);
            if (estudiante != null) {
                Object[] fila = {
                    estudiante.getId(),
                    estudiante.getApellidos(),
                    estudiante.getNombres(),
                    estudiante.getEdad()
                };
                modeloTabla.addRow(fila);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un estudiante con ID: " + id, 
                    "Sin resultados", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El ID debe ser un número válido.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarEstadisticas() {
        int total = controller.obtenerCantidadEstudiantes();
        
        if (total == 0) {
            JOptionPane.showMessageDialog(this, "No hay estudiantes registrados.", 
                "Estadísticas", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        List<Estudiante> estudiantes = controller.obtenerTodos();
        
        double edadPromedio = estudiantes.stream()
            .mapToInt(Estudiante::getEdad)
            .average()
            .orElse(0.0);
        
        int edadMinima = estudiantes.stream()
            .mapToInt(Estudiante::getEdad)
            .min()
            .orElse(0);
        
        int edadMaxima = estudiantes.stream()
            .mapToInt(Estudiante::getEdad)
            .max()
            .orElse(0);

        String mensaje = String.format(
            "Estadísticas del Sistema:\n\n" +
            "Total de estudiantes: %d\n" +
            "Edad promedio: %.2f años\n" +
            "Edad mínima: %d años\n" +
            "Edad máxima: %d años",
            total, edadPromedio, edadMinima, edadMaxima
        );

        JOptionPane.showMessageDialog(this, mensaje, "Estadísticas", JOptionPane.INFORMATION_MESSAGE);
    }

    private void limpiarFormulario() {
        txtId.setText("");
        txtApellidos.setText("");
        txtNombres.setText("");
        txtEdad.setText("");
        tablaEstudiantes.clearSelection();
    }
}

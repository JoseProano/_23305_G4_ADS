package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

/**
 * Controlador que maneja la lógica de negocio para estudiantes
 * Implementa la capa de lógica de negocio en la arquitectura de 3 capas
 * Actúa como intermediario entre la vista (UI) y el acceso a datos (DAO)
 */
public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();

    public boolean crearEstudiante(int id, String apellidos, String nombres, int edad) {
        // Validaciones básicas
        if (apellidos == null || apellidos.trim().isEmpty()) {
            return false;
        }
        if (nombres == null || nombres.trim().isEmpty()) {
            return false;
        }
        if (edad < 0 || edad > 150) {
            return false;
        }

        Estudiante estudiante = new Estudiante(id, apellidos.trim(), nombres.trim(), edad);
        return dao.agregar(estudiante);
    }

    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        // Validaciones básicas
        if (apellidos == null || apellidos.trim().isEmpty()) {
            return false;
        }
        if (nombres == null || nombres.trim().isEmpty()) {
            return false;
        }
        if (edad < 0 || edad > 150) {
            return false;
        }

        Estudiante estudiante = new Estudiante(id, apellidos.trim(), nombres.trim(), edad);
        return dao.actualizar(estudiante);
    }

    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }

    public int obtenerCantidadEstudiantes() {
        return dao.contarEstudiantes();
    }

    public boolean hayEstudiantes() {
        return !dao.estaVacia();
    }
}

package dao;

import java.util.ArrayList;
import java.util.List;
import model.Estudiante;

/**
 * Clase DAO (Data Access Object) para el manejo de datos de estudiantes
 * Implementa la capa de acceso a datos en la arquitectura de 3 capas
 * Realiza operaciones CRUD básicas en memoria
 */
public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();

    public boolean agregar(Estudiante estudiante) {
        if (buscarPorId(estudiante.getId()) != null) {
            return false;
        }
        estudiantes.add(estudiante);
        return true;
    }

    public List<Estudiante> listar() {
        return new ArrayList<>(estudiantes);
    }

    public Estudiante buscarPorId(int id) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getId() == id) {
                return estudiante;
            }
        }
        return null;
    }

    public boolean actualizar(Estudiante estudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudiante.getId()) {
                estudiantes.set(i, estudiante);
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(int id) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == id) {
                estudiantes.remove(i);
                return true;
            }
        }
        return false;
    }

    public int contarEstudiantes() {
        return estudiantes.size();
    }

    public boolean estaVacia() {
        return estudiantes.isEmpty();
    }
}

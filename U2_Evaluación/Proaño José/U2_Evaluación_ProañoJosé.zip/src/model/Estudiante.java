package model;

/**
 * Clase que representa la entidad Estudiante
 * Implementa el modelo de datos en la arquitectura MVC
 * Contiene los atributos básicos: id, apellidos, nombres y edad
 */
public class Estudiante {
    private int id;
    private String apellidos;
    private String nombres;
    private int edad;

    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    public int getId() { 
        return id; 
    }
    
    public void setId(int id) { 
        this.id = id; 
    }
    
    public String getApellidos() { 
        return apellidos; 
    }
    
    public void setApellidos(String apellidos) { 
        this.apellidos = apellidos; 
    }
    
    public String getNombres() { 
        return nombres; 
    }
    
    public void setNombres(String nombres) { 
        this.nombres = nombres; 
    }
    
    public int getEdad() { 
        return edad; 
    }
    
    public void setEdad(int edad) { 
        this.edad = edad; 
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "id=" + id +
                ", apellidos='" + apellidos + '\'' +
                ", nombres='" + nombres + '\'' +
                ", edad=" + edad +
                '}';
    }
}

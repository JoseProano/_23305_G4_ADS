package presentación;

import lógica_negocio.EstudianteService;
import datos.Model.Estudiante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Ventana principal para la gestión de estudiantes.
 *
 * Esta clase representa la interfaz gráfica de usuario (GUI) de la aplicación.
 * Permite al usuario crear, buscar, actualizar y eliminar estudiantes,
 * mostrando los datos en una tabla. Sirve como puente entre el usuario y la lógica de negocio.
 */
public class EstudianteUI extends JFrame {
    // Servicio de lógica de negocio para gestionar estudiantes
    private final EstudianteService service = new EstudianteService();

    // Campos de texto para ingresar datos del estudiante
    private final JTextField txtId = new JTextField(5);
    private final JTextField txtNombre = new JTextField(15);
    private final JTextField txtEdad = new JTextField(5);

    // Modelo y tabla para mostrar los estudiantes en la interfaz
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Edad"}, 0
    );
    private final JTable tabla = new JTable(modeloTabla);

    /**
     * Constructor que configura la ventana, los paneles y los eventos.
     * Organiza la interfaz en paneles para entrada de datos, botones y la tabla.
     * Conecta los botones y campos con sus respectivas acciones.
     */
    public EstudianteUI() {
        setTitle("Gestión de Estudiantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel de entrada de datos (arriba)
        JPanel panelEntrada = new JPanel();
        panelEntrada.add(new JLabel("ID:"));
        panelEntrada.add(txtId);
        panelEntrada.add(new JLabel("Nombre:"));
        panelEntrada.add(txtNombre);
        panelEntrada.add(new JLabel("Edad:"));
        panelEntrada.add(txtEdad);

        // Panel de botones (centro)
        JPanel panelBotones = new JPanel();
        JButton btnCrear = new JButton("Crear");
        JButton btnMostrar = new JButton("Mostrar Todos");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");

        panelBotones.add(btnCrear);
        panelBotones.add(btnMostrar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);

        // Tabla para mostrar estudiantes (abajo)
        JScrollPane scroll = new JScrollPane(tabla);

        add(panelEntrada, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        // Asignación de acciones a los botones
        btnCrear.addActionListener(this::crear);
        btnMostrar.addActionListener(_ -> mostrarTodos());
        btnActualizar.addActionListener(this::actualizar);
        btnEliminar.addActionListener(this::eliminar);

        // Búsqueda en tiempo real por ID al escribir en el campo correspondiente
        txtId.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
            public void removeUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
            public void changedUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
        });

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        mostrarTodos();
    }

    /**
     * Crea un nuevo estudiante con los datos ingresados y lo agrega al sistema.
     * Muestra un mensaje de confirmación o error.
     */
    private void crear(ActionEvent e) {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            int edad = Integer.parseInt(txtEdad.getText());
            service.crear(id, nombre, edad);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, "Estudiante creado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    /**
     * Muestra todos los estudiantes en la tabla.
     * Limpia la tabla y la llena con los datos actuales.
     */
    private void mostrarTodos() {
        modeloTabla.setRowCount(0);
        for (Estudiante est : service.listarTodos()) {
            modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
        }
    }

    /**
     * Busca un estudiante por ID en tiempo real mientras se escribe.
     * Si el campo está vacío, muestra todos los estudiantes.
     * Si el ID es válido y existe, muestra solo ese estudiante.
     */
    private void buscarEnTiempoReal() {
        String textoId = txtId.getText();
        if (textoId.isEmpty()) {
            mostrarTodos();
            return;
        }
        try {
            int id = Integer.parseInt(textoId);
            Estudiante est = service.leer(id);
            modeloTabla.setRowCount(0);
            if (est != null) {
                modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
            }
        } catch (NumberFormatException ex) {
            modeloTabla.setRowCount(0);
        }
    }

    /**
     * Actualiza los datos de un estudiante existente.
     * Muestra un mensaje de confirmación o error.
     */
    private void actualizar(ActionEvent e) {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            int edad = Integer.parseInt(txtEdad.getText());
            boolean ok = service.actualizar(id, nombre, edad);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, ok ? "Estudiante actualizado." : "No encontrado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    /**
     * Elimina un estudiante por ID.
     * Muestra un mensaje de confirmación o error.
     */
    private void eliminar(ActionEvent e) {
        try {
            int id = Integer.parseInt(txtId.getText());
            boolean ok = service.eliminar(id);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, ok ? "Estudiante eliminado." : "No encontrado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
package lógica_negocio;

import datos.Model.Estudiante;
import datos.Repository.EstudianteRepository;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Clase EstudianteService
 *
 * Esta clase representa la capa de lógica de negocio para la gestión de estudiantes.
 * Se encarga de coordinar las operaciones CRUD (crear, leer, actualizar, eliminar)
 * utilizando el repositorio de estudiantes como fuente de datos.
 * Sirve de intermediario entre la interfaz de usuario y la capa de datos.
 */
public class EstudianteService {
    // Instancia del repositorio que almacena los estudiantes
    private EstudianteRepository repo = new EstudianteRepository();

    /**
     * Crea y agrega un nuevo estudiante al repositorio.
     */
    public void crear(int id, String nombre, int edad) {
        repo.agregar(new Estudiante(id, nombre, edad));
    }

    /**
     * Busca y retorna un estudiante por su ID.
     */
    public Estudiante leer(int id) {
        return repo.buscar(id);
    }

    /**
     * Actualiza los datos de un estudiante existente.
     * @return true si se actualizó, false si no se encontró el estudiante.
     */
    public boolean actualizar(int id, String nombre, int edad) {
        Estudiante e = repo.buscar(id);
        if (e != null) {
            e.setNombre(nombre);
            e.setEdad(edad);
            return true;
        }
        return false;
    }

    /**
     * Elimina un estudiante por su ID.
     * @return true si se eliminó, false si no se encontró.
     */
    public boolean eliminar(int id) {
        return repo.eliminar(id);
    }

    /**
     * Devuelve una lista con todos los estudiantes almacenados.
     * Utiliza un Iterator para recorrer el repositorio y construir la lista.
     */
    public List<Estudiante> listarTodos() {
        List<Estudiante> lista = new ArrayList<>();
        Iterator<Estudiante> it = repo.obtenerIterator();
        while (it.hasNext()) {
            lista.add(it.next());
        }
        return lista;
    }
}

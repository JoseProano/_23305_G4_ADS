import presentación.EstudianteUI;

/**
 * Clase Main
 *
 * Punto de entrada de la aplicación.
 * Su función principal es iniciar la interfaz gráfica de usuario (GUI) para la gestión de estudiantes.
 * Utiliza SwingUtilities para asegurar que la interfaz se ejecute en el hilo de eventos de Swing,
 * lo cual es una buena práctica en aplicaciones Java con Swing.
 */
public class Main {
    public static void main(String[] args) {
        // Lanza la ventana principal de la aplicación en el hilo de eventos de Swing
        javax.swing.SwingUtilities.invokeLater(() -> new EstudianteUI());
    }
}

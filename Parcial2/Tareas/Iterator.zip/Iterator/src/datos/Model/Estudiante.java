package datos.Model;

/**
 * Clase Estudiante
 *
 * Representa el modelo de datos para un estudiante, encapsulando sus atributos principales:
 * id, nombre y edad. Esta clase se utiliza para crear objetos que almacenan y transfieren
 * la información de los estudiantes dentro de la aplicación.
 */
public class Estudiante {
    // Atributos que identifican y describen al estudiante
    private int id;
    private String nombre;
    private int edad;

    /**
     * Constructor principal.
     * Permite crear un estudiante con todos sus datos.
     */
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Métodos de acceso (getters y setters) para los atributos del estudiante
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    /**
     * Devuelve una representación en texto del estudiante.
     * Útil para mostrar información en la interfaz o para depuración.
     */
    @Override
    public String toString() {
        return id + " - " + nombre + " (" + edad + " años)";
    }
}

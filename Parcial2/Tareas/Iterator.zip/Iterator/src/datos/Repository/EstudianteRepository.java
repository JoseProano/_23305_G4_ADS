package datos.Repository;

import datos.Model.Estudiante;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Clase EstudianteRepository
 *
 * Esta clase funciona como un repositorio en memoria para objetos Estudiante.
 * Permite almacenar, buscar, eliminar y recorrer estudiantes, simulando una base de datos simple.
 * Es utilizada por la lógica de negocio para gestionar la colección de estudiantes.
 */
public class EstudianteRepository {
    // Lista interna que almacena los estudiantes en memoria
    private List<Estudiante> repositorio = new ArrayList<>();

    /**
     * Agrega un nuevo estudiante al repositorio.
     */
    public void agregar(Estudiante e) { repositorio.add(e); }

    /**
     * Elimina un estudiante por su ID.
     * Utiliza un Iterator para evitar problemas al eliminar durante la iteración.
     * @return true si se eliminó, false si no se encontró.
     */
    public boolean eliminar(int id) {
        Iterator<Estudiante> it = repositorio.iterator();
        while (it.hasNext()) {
            if (it.next().getId() == id) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    /**
     * Busca y retorna un estudiante por su ID.
     * @return El estudiante si existe, o null si no se encuentra.
     */
    public Estudiante buscar(int id) {
        for (Estudiante e : repositorio)
            if (e.getId() == id) return e;
        return null;
    }

    /**
     * Devuelve un Iterator para recorrer todos los estudiantes almacenados.
     * Útil para patrones de diseño como Iterator o para recorrer la colección externamente.
     */
    public Iterator<Estudiante> obtenerIterator() {
        return repositorio.iterator();
    }
}

package datos.Repository;

import datos.Model.Estudiante;
import java.util.*;

/**
 * Clase que representa el repositorio de estudiantes.
 * Se encarga de almacenar, buscar, actualizar y eliminar estudiantes en memoria.
 * Esta clase corresponde a la capa de acceso a datos de la aplicación.
 */
public class EstudianteRepository {
    // Mapa que almacena los estudiantes usando el id como clave
    private final Map<Integer, Estudiante> estudiantes = new HashMap<>();

    // Agrega un estudiante al repositorio
    public void agregar(Estudiante estudiante) {
        estudiantes.put(estudiante.getId(), estudiante);
    }

    // Busca un estudiante por su id
    public Estudiante buscarPorId(int id) {
        return estudiantes.get(id);
    }

    // Devuelve una lista con todos los estudiantes almacenados
    public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes.values());
    }

    // Actualiza la información de un estudiante existente
    public void actualizar(Estudiante estudiante) {
        estudiantes.put(estudiante.getId(), estudiante);
    }

    // Elimina un estudiante por su id
    public void eliminar(int id) {
        estudiantes.remove(id);
    }
}
package datos.Model;

/**
 * Clase que representa el modelo de un estudiante.
 * Contiene los atributos básicos y métodos para acceder y modificar los datos del estudiante.
 * Esta clase es utilizada en las demás capas para transferir información de los estudiantes.
 */
public class Estudiante {
    private int id;
    private String nombre;
    private int edad;

    // Constructor para inicializar los datos del estudiante
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Métodos getter y setter para acceder y modificar los atributos

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEdad(int edad) { this.edad = edad; }

    // Método para mostrar la información del estudiante como texto
    @Override
    public String toString() {
        return "Estudiante{id=" + id + ", nombre='" + nombre + "', edad=" + edad + '}';
    }
}
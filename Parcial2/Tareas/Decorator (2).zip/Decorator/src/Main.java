import datos.Repository.EstudianteRepository;
import logica_negocio.*;
import presentacion.EstudianteUI;

public class Main {
    public static void main(String[] args) {
        EstudianteRepository repo = new EstudianteRepository();

        
        IEstudianteService baseService = new EstudianteServiceBase(repo);
        IEstudianteService finalService = baseService; 

        new EstudianteUI(finalService);
    }
}

package logica_negocio;

import datos.Model.Estudiante;
import datos.Repository.EstudianteRepository;

import java.util.List;

/**
 * Clase base que implementa la lógica de negocio para el manejo de estudiantes.
 * Implementa la interfaz IEstudianteService.
 */
public class EstudianteServiceBase implements IEstudianteService {

    // Repositorio de estudiantes que maneja el almacenamiento y acceso a los datos
    private final EstudianteRepository repo;

    /**
     * Constructor que recibe el repositorio a utilizar.
     * @param repo el repositorio de estudiantes
     */
    public EstudianteServiceBase(EstudianteRepository repo) {
        this.repo = repo;
    }

    /**
     * Agrega un nuevo estudiante si no existe otro con el mismo ID.
     * @param id ID del estudiante
     * @param nombre Nombre del estudiante
     * @param edad Edad del estudiante
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        // Verifica si ya existe un estudiante con el mismo ID
        if (repo.buscarPorId(id) != null) {
            throw new IllegalArgumentException("El estudiante ya existe.");
        }
        // Si no existe, lo agrega al repositorio
        repo.agregar(new Estudiante(id, nombre, edad));
    }

    /**
     * Busca un estudiante por su ID.
     * @param id ID del estudiante a buscar
     * @return el objeto Estudiante si existe, o null si no
     */
    public Estudiante buscarEstudiante(int id) {
        return repo.buscarPorId(id);
    }

    /**
     * Obtiene una lista con todos los estudiantes almacenados.
     * @return lista de estudiantes
     */
    public List<Estudiante> obtenerTodos() {
        return repo.obtenerTodos();
    }

    /**
     * Actualiza los datos de un estudiante existente.
     * @param id ID del estudiante a actualizar
     * @param nombre Nuevo nombre
     * @param edad Nueva edad
     */
    public void actualizarEstudiante(int id, String nombre, int edad) {
        // Busca el estudiante por ID
        Estudiante est = repo.buscarPorId(id);
        // Si no existe, lanza excepción
        if (est == null) throw new IllegalArgumentException("No existe el estudiante.");
        // Actualiza nombre y edad
        est.setNombre(nombre);
        est.setEdad(edad);
        // Guarda los cambios en el repositorio
        repo.actualizar(est);
    }

    /**
     * Elimina un estudiante por su ID.
     * @param id ID del estudiante a eliminar
     */
    public void eliminarEstudiante(int id) {
        repo.eliminar(id);
    }
}

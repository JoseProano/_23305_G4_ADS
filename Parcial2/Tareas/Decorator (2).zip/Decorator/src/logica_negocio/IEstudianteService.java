package logica_negocio;

import datos.Model.Estudiante;
import java.util.List;

/**
 * Interfaz que define el contrato para la gestión de estudiantes.
 * Esta interfaz permite abstraer la lógica de negocio del manejo de estudiantes
 * y facilita el uso del patrón de diseño Decorator, ya que múltiples clases pueden implementarla.
 */
public interface IEstudianteService {

    /**
     * Agrega un nuevo estudiante.
     * @param id ID del estudiante
     * @param nombre Nombre del estudiante
     * @param edad Edad del estudiante
     */
    void agregarEstudiante(int id, String nombre, int edad);

    /**
     * Busca un estudiante por su ID.
     * @param id ID del estudiante a buscar
     * @return el estudiante encontrado o null si no existe
     */
    Estudiante buscarEstudiante(int id);

    /**
     * Obtiene una lista con todos los estudiantes registrados.
     * @return lista de estudiantes
     */
    List<Estudiante> obtenerTodos();

    /**
     * Actualiza los datos de un estudiante existente.
     * @param id ID del estudiante a actualizar
     * @param nombre Nuevo nombre
     * @param edad Nueva edad
     */
    void actualizarEstudiante(int id, String nombre, int edad);

    /**
     * Elimina un estudiante por su ID.
     * @param id ID del estudiante a eliminar
     */
    void eliminarEstudiante(int id);
}

package logica_negocio;

import datos.Model.Estudiante;
import java.util.List;

/**
 * Clase abstracta que actúa como decorador base para la interfaz IEstudianteService.
 * Implementa todos los métodos de la interfaz delegando las llamadas al servicio decorado.
 * Esta clase permite extender la funcionalidad del servicio original sin modificar su código.
 */
public abstract class EstudianteServiceDecorator implements IEstudianteService {

    // Referencia al servicio que se está decorando (puede ser EstudianteServiceBase o cualquier otro decorador)
    protected final IEstudianteService decorated;

    /**
     * Constructor que recibe el servicio a decorar.
     * @param decorated implementación concreta de IEstudianteService
     */
    public EstudianteServiceDecorator(IEstudianteService decorated) {
        this.decorated = decorated;
    }

    /**
     * Método para agregar un estudiante.
     * Delegado directamente al servicio decorado.
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        decorated.agregarEstudiante(id, nombre, edad);
    }

    /**
     * Método para buscar un estudiante por ID.
     * Delegado directamente al servicio decorado.
     */
    public Estudiante buscarEstudiante(int id) {
        return decorated.buscarEstudiante(id);
    }

    /**
     * Método para obtener todos los estudiantes.
     * Delegado directamente al servicio decorado.
     */
    public List<Estudiante> obtenerTodos() {
        return decorated.obtenerTodos();
    }

    /**
     * Método para actualizar los datos de un estudiante.
     * Delegado directamente al servicio decorado.
     */
    public void actualizarEstudiante(int id, String nombre, int edad) {
        decorated.actualizarEstudiante(id, nombre, edad);
    }

    /**
     * Método para eliminar un estudiante.
     * Delegado directamente al servicio decorado.
     */
    public void eliminarEstudiante(int id) {
        decorated.eliminarEstudiante(id);
    }
}
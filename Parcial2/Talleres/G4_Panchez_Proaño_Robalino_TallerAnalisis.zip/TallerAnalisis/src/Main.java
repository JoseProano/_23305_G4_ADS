import datos.Repository.EstudianteRepository;
import logica_negocio.EstudianteService;
import presentacion.EstudianteUI;

/**
 * Clase principal que inicia la aplicación.
 * Aquí se crean las instancias de las capas: repositorio, servicio y presentación (UI).
 * La interfaz gráfica se muestra al usuario para gestionar estudiantes.
 */
public class Main {
    public static void main(String[] args) {
        // Se crea el repositorio (capa de acceso a datos)
        EstudianteRepository repo = new EstudianteRepository();
        // Se crea el servicio (lógica de negocio) usando el repositorio
        EstudianteService service = new EstudianteService(repo);
        // Se crea y muestra la interfaz gráfica, usando el servicio
        new EstudianteUI(service);
    }
}
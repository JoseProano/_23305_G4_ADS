package logica_negocio;

import datos.Model.Estudiante;
import datos.Repository.EstudianteRepository;
import java.util.List;

/**
 * Clase de servicio que representa la lógica de negocio para la gestión de estudiantes.
 * Aquí se validan las reglas antes de interactuar con el repositorio.
 * Esta clase conecta la capa de presentación con la de datos.
 */
public class EstudianteService {
    // Referencia al repositorio de estudiantes (capa de acceso a datos)
    private final EstudianteRepository repo;

    // Constructor que recibe el repositorio a utilizar
    public EstudianteService(EstudianteRepository repo) {
        this.repo = repo;
    }

    // Métodos de negocio para el CRUD de estudiantes

    /**
     * Agrega un nuevo estudiante si el id no existe.
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        if (repo.buscarPorId(id) != null) {
            throw new IllegalArgumentException("El estudiante ya existe.");
        }
        repo.agregar(new Estudiante(id, nombre, edad));
    }

    /**
     * Busca un estudiante por su id.
     */
    public Estudiante buscarEstudiante(int id) {
        return repo.buscarPorId(id);
    }

    /**
     * Obtiene la lista de todos los estudiantes.
     */
    public List<Estudiante> obtenerTodos() {
        return repo.obtenerTodos();
    }

    /**
     * Actualiza los datos de un estudiante existente.
     */
    public void actualizarEstudiante(int id, String nombre, int edad) {
        Estudiante est = repo.buscarPorId(id);
        if (est == null) throw new IllegalArgumentException("No existe el estudiante.");
        est.setNombre(nombre);
        est.setEdad(edad);
        repo.actualizar(est);
    }

    /**
     * Elimina un estudiante por su id.
     */
    public void eliminarEstudiante(int id) {
        repo.eliminar(id);
    }
}
package presentacion;

import logica_negocio.EstudianteService;
import datos.Model.Estudiante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Ventana principal de la aplicación CRUD de estudiantes.
 * Esta clase representa la capa de presentación usando Swing.
 * Permite al usuario agregar, mostrar, buscar, actualizar y eliminar estudiantes,
 * mostrando los datos en una tabla organizada.
 */
public class EstudianteUI extends JFrame {
    // Referencia al servicio de lógica de negocio
    private final EstudianteService service;
    // Campos de texto para entrada de datos
    private final JTextField campoId = new JTextField(5);
    private final JTextField campoNombre = new JTextField(15);
    private final JTextField campoEdad = new JTextField(5);

    // Modelo y tabla para mostrar los estudiantes de forma organizada
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Edad"}, 0
    );
    private final JTable tabla = new JTable(modeloTabla);

    /**
     * Constructor que configura la interfaz gráfica,
     * organiza los paneles y conecta los botones con sus acciones.
     */
    public EstudianteUI(EstudianteService service) {
        this.service = service;
        setTitle("CRUD Estudiantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel de entrada de datos
        JPanel panelEntrada = new JPanel();
        panelEntrada.add(new JLabel("ID:"));
        panelEntrada.add(campoId);
        panelEntrada.add(new JLabel("Nombre:"));
        panelEntrada.add(campoNombre);
        panelEntrada.add(new JLabel("Edad:"));
        panelEntrada.add(campoEdad);

        // Panel de botones para las operaciones CRUD
        JPanel panelBotones = new JPanel();
        JButton btnAgregar = new JButton("Agregar");
        JButton btnMostrar = new JButton("Mostrar Todos");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnMostrar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);

        // Área de tabla para mostrar los estudiantes
        JScrollPane scroll = new JScrollPane(tabla);

        add(panelEntrada, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        // Asignación de acciones a los botones
        btnAgregar.addActionListener(this::agregar);
        btnMostrar.addActionListener(_ -> mostrarTodos());
        btnActualizar.addActionListener(this::actualizar);
        btnEliminar.addActionListener(this::eliminar);

        // Búsqueda en tiempo real al escribir en el campo de ID
        campoId.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
            public void removeUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
            public void changedUpdate(DocumentEvent e) { buscarEnTiempoReal(); }
        });

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Métodos privados para manejar cada acción CRUD y actualizar la tabla

    private void agregar(ActionEvent e) {
        try {
            int id = Integer.parseInt(campoId.getText());
            String nombre = campoNombre.getText();
            int edad = Integer.parseInt(campoEdad.getText());
            service.agregarEstudiante(id, nombre, edad);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, "Estudiante agregado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void mostrarTodos() {
        modeloTabla.setRowCount(0); // Limpiar tabla
        for (Estudiante est : service.obtenerTodos()) {
            modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
        }
    }

    // Búsqueda en tiempo real según lo que se escriba en el campo de ID
    private void buscarEnTiempoReal() {
        String textoId = campoId.getText();
        if (textoId.isEmpty()) {
            mostrarTodos();
            return;
        }
        try {
            int id = Integer.parseInt(textoId);
            Estudiante est = service.buscarEstudiante(id);
            modeloTabla.setRowCount(0);
            if (est != null) {
                modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
            }
        } catch (NumberFormatException ex) {
            modeloTabla.setRowCount(0); // Si no es un número, limpia la tabla
        }
    }

    private void actualizar(ActionEvent e) {
        try {
            int id = Integer.parseInt(campoId.getText());
            String nombre = campoNombre.getText();
            int edad = Integer.parseInt(campoEdad.getText());
            service.actualizarEstudiante(id, nombre, edad);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, "Estudiante actualizado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void eliminar(ActionEvent e) {
        try {
            int id = Integer.parseInt(campoId.getText());
            service.eliminarEstudiante(id);
            mostrarTodos();
            JOptionPane.showMessageDialog(this, "Estudiante eliminado.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}